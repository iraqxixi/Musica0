package com.musica.app;

import android.content.ContentUris;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.MediaMetadataRetriever;
import android.provider.MediaStore;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

final class Util {
    private Util() {}

    /** Cover art for a MediaStore audio id (embedded picture, shrunk, cached on disk). Never null. */
    static byte[] art(Context c, long id) {
        File dir = new File(c.getCacheDir(), "art");
        dir.mkdirs();
        File f = new File(dir, id + ".jpg");
        try {
            if (f.exists() && f.length() > 0) return readAll(f);
        } catch (Exception ignored) {}
        byte[] out = null;
        MediaMetadataRetriever m = new MediaMetadataRetriever();
        try {
            m.setDataSource(c, ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id));
            byte[] pic = m.getEmbeddedPicture();
            if (pic != null) out = shrink(pic);
        } catch (Exception ignored) {
        } finally {
            try { m.release(); } catch (Exception ignored) {}
        }
        if (out == null) out = placeholder(id);
        try {
            FileOutputStream o = new FileOutputStream(f);
            o.write(out);
            o.close();
        } catch (Exception ignored) {}
        return out;
    }

    static byte[] shrink(byte[] pic) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(pic, 0, pic.length, o);
        int s = 1;
        while (o.outWidth / (s * 2) >= 480) s *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = s;
        Bitmap bm = BitmapFactory.decodeByteArray(pic, 0, pic.length, o2);
        if (bm == null) return null;
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 86, bo);
        bm.recycle();
        return bo.toByteArray();
    }

    static byte[] placeholder(long id) {
        Bitmap b = Bitmap.createBitmap(300, 300, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float[] hsv = new float[]{(float) ((id * 47L) % 360L), 0.45f, 0.35f};
        cv.drawColor(Color.HSVToColor(hsv));
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0xCCFFFFFF);
        p.setTextSize(150f);
        p.setTextAlign(Paint.Align.CENTER);
        cv.drawText("\u266A", 150f, 200f, p);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.JPEG, 85, bo);
        b.recycle();
        return bo.toByteArray();
    }

    static byte[] readAll(File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        try {
            byte[] buf = new byte[(int) f.length()];
            int off = 0;
            while (off < buf.length) {
                int n = in.read(buf, off, buf.length - off);
                if (n < 0) break;
                off += n;
            }
            return buf;
        } finally {
            in.close();
        }
    }
}
