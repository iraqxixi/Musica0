package com.musica.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;

import androidx.core.app.NotificationCompat;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MediaService extends Service {
    static final String CH = "musica_play";
    static final String A_UPDATE = "com.musica.app.UPDATE";
    static final String A_PLAY = "com.musica.app.PLAY";
    static final String A_PAUSE = "com.musica.app.PAUSE";
    static final String A_NEXT = "com.musica.app.NEXT";
    static final String A_PREV = "com.musica.app.PREV";

    static MediaService inst;

    MediaSessionCompat session;
    final Handler h = new Handler(Looper.getMainLooper());
    final ExecutorService ex = Executors.newSingleThreadExecutor();
    PowerManager.WakeLock wl;
    boolean fg = false;

    String id = "", title = "", artist = "";
    boolean playing = false;
    long pos = 0, dur = 0;
    Bitmap art = null;

    /** Called from the JS bridge (any thread). */
    static void push(Context c, String id, String title, String artist, boolean playing, long pos, long dur) {
        final MediaService s = inst;
        if (s != null) {
            final String fi = id, ft = title, fa = artist;
            final boolean fp = playing;
            final long fpos = pos, fd = dur;
            s.h.post(() -> s.update(fi, ft, fa, fp, fpos, fd));
            return;
        }
        try {
            Intent i = new Intent(c, MediaService.class).setAction(A_UPDATE)
                    .putExtra("id", id).putExtra("t", title).putExtra("a", artist)
                    .putExtra("p", playing).putExtra("pos", pos).putExtra("dur", dur);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
        } catch (Exception ignored) {}
    }

    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "Musica", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
        session = new MediaSessionCompat(this, "Musica");
        session.setCallback(new MediaSessionCompat.Callback() {
            @Override public void onPlay() { cmd("play"); }
            @Override public void onPause() { cmd("pause"); }
            @Override public void onSkipToNext() { cmd("next"); }
            @Override public void onSkipToPrevious() { cmd("prev"); }
            @Override public void onSeekTo(long p) { cmd("seek:" + p); }
        });
        session.setActive(true);
    }

    @Override
    public int onStartCommand(Intent in, int flags, int startId) {
        if (in != null && in.getAction() != null) {
            String a = in.getAction();
            if (A_UPDATE.equals(a)) {
                update(in.getStringExtra("id"), in.getStringExtra("t"), in.getStringExtra("a"),
                        in.getBooleanExtra("p", false), in.getLongExtra("pos", 0), in.getLongExtra("dur", 0));
            } else if (A_PLAY.equals(a)) cmd("play");
            else if (A_PAUSE.equals(a)) cmd("pause");
            else if (A_NEXT.equals(a)) cmd("next");
            else if (A_PREV.equals(a)) cmd("prev");
        }
        if (!fg) build();
        return START_NOT_STICKY;
    }

    void cmd(String c) {
        MainActivity a = MainActivity.inst;
        if (a != null) a.sendCmd(c);
    }

    void update(String nid, String t, String a, boolean p, long ps, long d) {
        if (nid == null) nid = "";
        boolean changed = !nid.equals(id);
        id = nid;
        title = t == null ? "" : t;
        artist = a == null ? "" : a;
        playing = p;
        pos = ps;
        dur = d;
        if (changed) {
            art = null;
            loadArt(nid);
        }
        if (p) {
            if (wl == null) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "musica:play");
            }
            if (!wl.isHeld()) wl.acquire(6L * 60 * 60 * 1000);
        } else if (wl != null && wl.isHeld()) {
            wl.release();
        }
        build();
    }

    void loadArt(final String nid) {
        if (!nid.startsWith("ms:")) return;
        final long n;
        try { n = Long.parseLong(nid.substring(3)); } catch (Exception e) { return; }
        ex.execute(() -> {
            byte[] b = Util.art(MediaService.this, n);
            final Bitmap bm = b == null ? null : BitmapFactory.decodeByteArray(b, 0, b.length);
            h.post(() -> {
                if (nid.equals(id) && bm != null) {
                    art = bm;
                    build();
                }
            });
        });
    }

    PendingIntent pi(String action, int code) {
        Intent i = new Intent(this, MediaService.class).setAction(action);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getService(this, code, i, fl);
    }

    void build() {
        MediaMetadataCompat.Builder mb = new MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, title)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, artist)
                .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, dur);
        if (art != null) mb.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, art);
        session.setMetadata(mb.build());
        long acts = PlaybackStateCompat.ACTION_PLAY | PlaybackStateCompat.ACTION_PAUSE
                | PlaybackStateCompat.ACTION_PLAY_PAUSE | PlaybackStateCompat.ACTION_SKIP_TO_NEXT
                | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS | PlaybackStateCompat.ACTION_SEEK_TO;
        session.setPlaybackState(new PlaybackStateCompat.Builder()
                .setActions(acts)
                .setState(playing ? PlaybackStateCompat.STATE_PLAYING : PlaybackStateCompat.STATE_PAUSED,
                        pos, playing ? 1f : 0f)
                .build());

        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        NotificationCompat.Builder nb = new NotificationCompat.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_stat_music)
                .setContentTitle(title.isEmpty() ? "Musica" : title)
                .setContentText(artist)
                .setContentIntent(content)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setOngoing(playing)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .addAction(R.drawable.ic_prev, "Previous", pi(A_PREV, 1))
                .addAction(playing ? R.drawable.ic_pause : R.drawable.ic_play, playing ? "Pause" : "Play",
                        pi(playing ? A_PAUSE : A_PLAY, 2))
                .addAction(R.drawable.ic_next, "Next", pi(A_NEXT, 3))
                .setStyle(new androidx.media.app.NotificationCompat.MediaStyle()
                        .setMediaSession(session.getSessionToken())
                        .setShowActionsInCompactView(0, 1, 2));
        if (art != null) nb.setLargeIcon(art);
        Notification n = nb.build();

        if (!fg) {
            if (Build.VERSION.SDK_INT >= 29)
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(1, n);
            fg = true;
        } else {
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(1, n);
        }
    }

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onDestroy() {
        inst = null;
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) {}
        try { session.release(); } catch (Exception ignored) {}
        ex.shutdownNow();
        super.onDestroy();
    }
}
