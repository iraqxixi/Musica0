package com.musica.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    static MainActivity inst;
    static final String HOST = "appassets.androidplatform.net";
    static final int REQ_PERM = 11, REQ_FILE = 12;

    WebView web;
    WebViewAssetLoader loader;
    ValueCallback<Uri[]> chooserCb;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        inst = this;
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30
                    ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);

        loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        setContentView(web);

        // keep the web content above the keyboard while still drawing edge to edge
        ViewCompat.setOnApplyWindowInsetsListener(web, (v, insets) -> {
            Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            v.setPadding(0, 0, 0, ime.bottom);
            return insets;
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        WebView.setWebContentsDebuggingEnabled(true);

        web.addJavascriptInterface(new Bridge(), "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String p = u.getPath();
                if (p == null) return null;
                try {
                    if (p.equals("/api/songs")) return songs();
                    if (p.startsWith("/media/")) return media(Long.parseLong(p.substring(7)), r.getRequestHeaders());
                    if (p.startsWith("/art/")) return art(Long.parseLong(p.substring(5)));
                } catch (Exception e) {
                    return status(500, "error");
                }
                return loader.shouldInterceptRequest(u);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {}
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooserCb != null) chooserCb.onReceiveValue(null);
                chooserCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    chooserCb = null;
                    return false;
                }
                return true;
            }
        });

        web.loadUrl("https://" + HOST + "/assets/index.html");
    }

    // ---------- permissions ----------
    boolean hasPerm() {
        String p = Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_AUDIO
                : Manifest.permission.READ_EXTERNAL_STORAGE;
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_PERM) {
            web.evaluateJavascript("window.onPerm&&window.onPerm(" + hasPerm() + ")", null);
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && chooserCb != null) {
            chooserCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            chooserCb = null;
        }
    }

    // ---------- JS bridge ----------
    class Bridge {
        @JavascriptInterface
        public boolean hasPerm() {
            return MainActivity.this.hasPerm();
        }

        @JavascriptInterface
        public void reqPerm() {
            runOnUiThread(() -> {
                ArrayList<String> l = new ArrayList<>();
                if (Build.VERSION.SDK_INT >= 33) {
                    l.add(Manifest.permission.READ_MEDIA_AUDIO);
                    l.add(Manifest.permission.POST_NOTIFICATIONS);
                } else {
                    l.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                }
                requestPermissions(l.toArray(new String[0]), REQ_PERM);
            });
        }

        @JavascriptInterface
        public void np(String id, String title, String artist, boolean playing, long pos, long dur) {
            MediaService.push(MainActivity.this, id, title, artist, playing, pos, dur);
        }
    }

    void sendCmd(String cmd) {
        runOnUiThread(() -> {
            if (web != null) web.evaluateJavascript("window.onCmd&&window.onCmd('" + cmd + "')", null);
        });
    }

    // ---------- local content served to the page ----------
    WebResourceResponse status(int code, String msg) {
        return new WebResourceResponse("text/plain", "utf-8", code, msg, new HashMap<String, String>(),
                new ByteArrayInputStream(new byte[0]));
    }

    WebResourceResponse songs() throws Exception {
        JSONArray a = new JSONArray();
        if (hasPerm()) {
            String[] proj = {
                    MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DATE_ADDED,
                    MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.MIME_TYPE, MediaStore.Audio.Media.DISPLAY_NAME,
                    MediaStore.Audio.Media.TRACK
            };
            String sel = MediaStore.Audio.Media.IS_MUSIC + "!=0 AND " + MediaStore.Audio.Media.DURATION + ">=20000";
            Cursor c = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, sel, null,
                    MediaStore.Audio.Media.DATE_ADDED + " DESC");
            if (c != null) {
                try {
                    while (c.moveToNext()) {
                        JSONObject o = new JSONObject();
                        o.put("id", c.getLong(0));
                        o.put("t", c.getString(1));
                        o.put("a", c.getString(2));
                        o.put("b", c.getString(3));
                        o.put("u", c.getLong(4));
                        o.put("d", c.getLong(5));
                        o.put("s", c.getLong(6));
                        o.put("m", c.getString(7));
                        o.put("n", c.getString(8));
                        o.put("k", c.getLong(9));
                        a.put(o);
                    }
                } finally {
                    c.close();
                }
            }
        }
        Map<String, String> h = new HashMap<>();
        h.put("Cache-Control", "no-store");
        WebResourceResponse r = new WebResourceResponse("application/json", "utf-8",
                new ByteArrayInputStream(a.toString().getBytes("UTF-8")));
        r.setResponseHeaders(h);
        return r;
    }

    WebResourceResponse art(long id) {
        byte[] b = Util.art(this, id);
        Map<String, String> h = new HashMap<>();
        h.put("Cache-Control", "public, max-age=86400");
        WebResourceResponse r = new WebResourceResponse("image/jpeg", null, new ByteArrayInputStream(b));
        r.setResponseHeaders(h);
        return r;
    }

    WebResourceResponse media(long id, Map<String, String> hdr) throws Exception {
        Uri uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
        ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(uri, "r");
        if (pfd == null) return status(404, "not found");
        long len = pfd.getStatSize();
        if (len <= 0) {
            pfd.close();
            return status(404, "empty");
        }
        String mime = getContentResolver().getType(uri);
        if (mime == null) mime = "audio/mpeg";
        long start = 0, end = len - 1;
        boolean part = false;
        String rg = null;
        for (Map.Entry<String, String> e : hdr.entrySet()) {
            if (e.getKey().equalsIgnoreCase("Range")) rg = e.getValue();
        }
        if (rg != null && rg.startsWith("bytes=")) {
            String[] x = rg.substring(6).split("-", 2);
            try {
                if (x[0].trim().isEmpty()) {
                    long n = Long.parseLong(x[1].trim());
                    start = Math.max(0, len - n);
                } else {
                    start = Long.parseLong(x[0].trim());
                    if (x.length > 1 && !x[1].trim().isEmpty()) end = Long.parseLong(x[1].trim());
                }
                part = true;
            } catch (Exception ignored) {
                start = 0;
                end = len - 1;
                part = false;
            }
            if (start >= len) {
                pfd.close();
                return status(416, "Range Not Satisfiable");
            }
            if (end >= len) end = len - 1;
        }
        FileInputStream fis = new FileInputStream(pfd.getFileDescriptor());
        fis.getChannel().position(start);
        InputStream in = new RangeStream(fis, pfd, end - start + 1);
        Map<String, String> h = new HashMap<>();
        h.put("Accept-Ranges", "bytes");
        h.put("Content-Length", String.valueOf(end - start + 1));
        h.put("Cache-Control", "no-cache");
        if (part) {
            h.put("Content-Range", "bytes " + start + "-" + end + "/" + len);
            return new WebResourceResponse(mime, null, 206, "Partial Content", h, in);
        }
        return new WebResourceResponse(mime, null, 200, "OK", h, in);
    }

    static class RangeStream extends InputStream {
        final FileInputStream f;
        final ParcelFileDescriptor p;
        long left;
        final byte[] one = new byte[1];

        RangeStream(FileInputStream f, ParcelFileDescriptor p, long left) {
            this.f = f;
            this.p = p;
            this.left = left;
        }

        @Override
        public int read() throws IOException {
            int n = read(one, 0, 1);
            return n < 0 ? -1 : (one[0] & 0xff);
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int n = f.read(b, off, (int) Math.min((long) len, left));
            if (n > 0) left -= n;
            return n;
        }

        @Override
        public void close() {
            try { f.close(); } catch (Exception ignored) {}
            try { p.close(); } catch (Exception ignored) {}
        }
    }

    // ---------- full-screen immersive ----------
    void immersive() {
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        c.hide(WindowInsetsCompat.Type.systemBars());
    }

    @Override
    public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) immersive();
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        inst = null;
        try { stopService(new Intent(this, MediaService.class)); } catch (Exception ignored) {}
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
